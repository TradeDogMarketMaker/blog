# Licence

This repository holds three kinds of material, each under its own terms.

## 1. Charts, images and data: CC BY 4.0

Files in `images/` and `data/` are © 2026 TDMM Ltd (TradeDog Market Maker). They are licensed under the **Creative Commons Attribution 4.0 International** licence (CC BY 4.0): https://creativecommons.org/licenses/by/4.0/

You may share and adapt them for any purpose, including commercially, as long as you give appropriate credit. Please credit them like this:

> Source: TDMM Research, "Crypto Market Maker vs Liquidity Provider: Which Is Better for a New Token Project?", 29 September 2026, https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/ (CC BY 4.0)

Third-party figures reproduced in the charts, such as Bancor's Uniswap v3 study and Binance programme terms, remain the work of their authors. They are cited in each chart's source line and in the article's source list.

## 2. Scripts: MIT licence

Copyright (c) 2026 TDMM Ltd

Permission is hereby granted, free of charge, to any person obtaining a copy of the files in `scripts/` (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

## 3. Article text: all rights reserved

The article text in `README.md` and `_posts/` is © 2026 TDMM Ltd, and all rights are reserved. You are welcome to quote short passages with attribution and a link to the original at https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/. Republishing the full text requires written permission from TDMM.

"TDMM", "TradeDog Market Maker" and the TDMM logo are trademarks of TDMM Ltd and are not licensed under any of the terms above.
