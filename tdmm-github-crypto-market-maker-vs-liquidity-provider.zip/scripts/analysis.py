"""Where does a listed token's liquidity sit? Gate order book vs its DEX pools. Output: live.json"""
import json, statistics as st, math
import numpy as np
D = json.load(open("pairs.json"))
import os
vol = json.load(open("vol.json")) if os.path.exists("vol.json") else {}
rows = D["rows"]
CP_LABELS = {"v2", "v1", "CPMM", "DYN", "DYN2"}
CP_DEX_BARE = {"raydium", "pumpswap", "sushiswap", "pancakeswap", "biswap", "apeswap", "shibaswap", "quickswap", "babyswap", "mdex", "defiswap", "squadswap", "fluxbeam"}
CL_LABELS = {"v3", "v4", "wp", "CLMM", "DLMM", "CLAMM"}
FEE = 0.003

def tier(mc):
    return "Under $5M" if mc < 5e6 else "$5M to $25M" if mc < 25e6 else "$25M to $100M" if mc < 100e6 else "$100M to $1B"
TIERS = ["Under $5M", "$5M to $25M", "$25M to $100M", "$100M to $1B"]

def depth(r, pct=0.02):
    bids = [(float(p), float(q)) for p, q in r["bids"]]
    asks = [(float(p), float(q)) for p, q in r["asks"]]
    if not bids or not asks:
        return None
    bb, ba = bids[0][0], asks[0][0]
    mid = (bb + ba) / 2
    sp = (ba - bb) / mid * 1e4
    bd = sum(p * q for p, q in bids if p >= mid * (1 - pct))
    ad = sum(p * q for p, q in asks if p <= mid * (1 + pct))
    trunc = (bids[-1][0] >= mid * (1 - pct)) or (asks[-1][0] <= mid * (1 + pct))
    return dict(mid=mid, spread=sp, bid=bd, ask=ad, two=bd + ad, thin=min(bd, ad), trunc=trunc)

out = []
for r in rows:
    if not r.get("bids") or not r.get("asks"):
        continue
    d = depth(r)
    if not d:
        continue
    pools = [p for p in r["pools"] if p["reserve"] > 0]
    tvl = sum(p["reserve"] for p in pools)
    cp = [p for p in pools if (set(p["labels"]) & CP_LABELS) or (not p["labels"] and p["dex"] in CP_DEX_BARE)]
    cl = [p for p in pools if set(p["labels"]) & CL_LABELS]
    cp_tvl = sum(p["reserve"] for p in cp)
    cl_tvl = sum(p["reserve"] for p in cl)
    dvol = sum(p["vol24"] for p in r["pools"])
    v = vol.get(r["pair"], {}).get("vol")
    rec = dict(pair=r["pair"], chain=r["chain"], mc=r["mc"], tier=tier(r["mc"]), gate_vol=r["gate_vol"],
               spread=d["spread"], gate_two=d["two"], gate_thin=d["thin"], trunc=d["trunc"],
               tvl=tvl, cp_tvl=cp_tvl, cl_tvl=cl_tvl, npools=len(pools), dex_vol=dvol,
               cp_depth=cp_tvl * 0.0100005, fr_depth=tvl * 0.0100005, sigma=v)
    if v:
        rec["lvr_day"] = tvl * v * v / 8 / 365
        rec["fee_day"] = dvol * FEE
        rec["covers"] = rec["fee_day"] >= rec["lvr_day"] if tvl > 0 else None
        rec["turnover"] = dvol / tvl if tvl > 0 else None
        rec["breakeven_turnover"] = v * v / 8 / 365 / FEE
    out.append(rec)

def med(x):
    x = [a for a in x if a is not None]
    return st.median(x) if x else None
def q(x, p):
    x = [a for a in x if a is not None]
    return float(np.percentile(x, p)) if x else None
def share(x):
    x = [a for a in x if a is not None]
    return sum(1 for a in x if a) / len(x) if x else None

res = dict(snapshot=dict(started=D["started"], finished=D["finished"]), n=len(out), tiers={})
for t in TIERS + ["All"]:
    g = [o for o in out if o["tier"] == t or t == "All"]
    withpool = [o for o in g if o["tvl"] > 0]
    res["tiers"][t] = dict(
        n=len(g),
        n_with_pool=len(withpool),
        share_no_pool_over_10k=share([o["tvl"] < 10_000 for o in g]),
        median_gate_two=med([o["gate_two"] for o in g]),
        median_gate_spread=med([o["spread"] for o in g]),
        median_tvl=med([o["tvl"] for o in g]),
        median_tvl_with_pool=med([o["tvl"] for o in withpool]),
        median_fr_depth=med([o["fr_depth"] for o in g]),
        share_pool_fr_depth_gt_gate=share([o["fr_depth"] > o["gate_two"] for o in g]),
        median_ratio_tvl_to_gate_depth=med([o["tvl"] / o["gate_two"] for o in withpool if o["gate_two"] > 0]),
        dex_vol_share_median=med([o["dex_vol"] / (o["dex_vol"] + o["gate_vol"]) for o in g if (o["dex_vol"] + o["gate_vol"]) > 0]),
        agg_dex_vol_share=sum(o["dex_vol"] for o in g) / max(1, sum(o["dex_vol"] + o["gate_vol"] for o in g)),
        agg_gate_depth=sum(o["gate_two"] for o in g), agg_fr_depth=sum(o["fr_depth"] for o in g),
        agg_tvl=sum(o["tvl"] for o in g),
        cl_share_of_tvl=sum(o["cl_tvl"] for o in g) / max(1, sum(o["tvl"] for o in g)),
        cp_share_of_tvl=sum(o["cp_tvl"] for o in g) / max(1, sum(o["tvl"] for o in g)),
        median_sigma=med([o["sigma"] for o in g]),
        share_pools_cover_lvr=share([o.get("covers") for o in withpool if o.get("sigma")]),
        n_lvr=len([o for o in withpool if o.get("sigma")]),
        median_turnover=med([o.get("turnover") for o in withpool]),
        median_breakeven_turnover=med([o.get("breakeven_turnover") for o in withpool]),
        share_gate_thin=share([o["gate_thin"] < 10_000 for o in g]),
        n_cp_dom=len([o for o in withpool if o["cp_tvl"] >= 0.9 * o["tvl"]]),
        cp_dom_share_pool_beats_gate=share([o["cp_depth"] > o["gate_two"] for o in withpool if o["cp_tvl"] >= 0.9 * o["tvl"]]),
        cp_dom_median_tvl=med([o["tvl"] for o in withpool if o["cp_tvl"] >= 0.9 * o["tvl"]]),
        cp_dom_median_cp_depth=med([o["cp_depth"] for o in withpool if o["cp_tvl"] >= 0.9 * o["tvl"]]),
        cp_dom_median_gate_two=med([o["gate_two"] for o in withpool if o["cp_tvl"] >= 0.9 * o["tvl"]]),
        share_tvl_under_100k=share([o["tvl"] < 100_000 for o in g]),
        median_dex_vol=med([o["dex_vol"] for o in g]),
        median_gate_vol=med([o["gate_vol"] for o in g]),
    )
res["n_trunc"] = sum(1 for o in out if o["trunc"])
res["chains"] = {c: sum(1 for o in out if o["chain"] == c) for c in set(o["chain"] for o in out)}
json.dump(res, open("live.json", "w"), indent=1)
json.dump(out, open("live_rows.json", "w"))
for t, v in res["tiers"].items():
    print(t, {k: (round(x, 4) if isinstance(x, float) else x) for k, x in v.items()})
print(res["n"], res["n_trunc"], res["chains"], res["snapshot"])
