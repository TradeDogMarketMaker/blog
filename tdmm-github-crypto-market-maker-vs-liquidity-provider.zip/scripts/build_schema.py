"""Build the supplementary JSON-LD block for the pillar from article.md (FAQ, HowTo, glossary, images verbatim).
Does NOT declare BlogPosting/Article/WebPage/WebSite/BreadcrumbList (AIOSEO emits those)."""
import json, re
s = open("article.md").read()
L = json.load(open("live.json"))
URL = "https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/"
IMG = "https://tdmm.io/insights/wp-content/uploads/2026/09/"
CC = "https://creativecommons.org/licenses/by/4.0/"
ORG = {"@id": "https://tdmm.io/#organization"}

def plain(md):
    md = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", md)
    return md.replace("**", "").replace("*", "").strip()

# FAQ
faq_block = s[s.index("## Frequently asked questions"):s.index("## Glossary")]
qa = re.findall(r"\*\*\d+\. (.+?)\*\*\n\n(.+?)(?=\n\n\*\*\d+\.|\n\n---)", faq_block, re.S)
faq = {"@type": "FAQPage", "@id": URL + "#faq", "isPartOf": {"@id": URL + "#webpage"},
       "mainEntity": [{"@type": "Question", "name": plain(q), "acceptedAnswer": {"@type": "Answer", "text": plain(a)}} for q, a in qa]}
# HowTo
ht = s[s.index("## How to decide between a market maker and a liquidity provider in 30 days"):s.index("![Seven question cards")]
steps = re.findall(r"\*\*(Days [^*]+?):\s*([^*]+?)\*\*\s(.+?)(?=\n\n)", ht, re.S)
howto = {"@type": "HowTo", "@id": URL + "#howto", "name": "How to decide between a market maker and a liquidity provider in 30 days",
         "totalTime": "P30D", "step": [{"@type": "HowToStep", "position": i + 1, "name": f"{d}: {n.rstrip('.')}", "text": plain(t)} for i, (d, n, t) in enumerate(steps)]}
# Glossary
gl = s[s.index("## Glossary"):s.index("## Sources")]
terms = re.findall(r"\*\*(.+?)\.\*\*\s(.+?)(?=\n\n|\n---)", gl, re.S)
dts = {"@type": "DefinedTermSet", "@id": URL + "#glossary", "name": "Market maker and liquidity provider glossary",
       "hasDefinedTerm": [{"@type": "DefinedTerm", "name": t, "description": plain(d), "inDefinedTermSet": {"@id": URL + "#glossary"}} for t, d in terms]}
# Related
rel = s[s.index("## Related TDMM guides and comparisons"):s.index("## Frequently asked questions")]
links = re.findall(r"\| \[([^\]]+)\]\((https://tdmm\.io/[^)]+)\)", rel)
itemlist = {"@type": "ItemList", "@id": URL + "#related", "name": "Related TDMM guides and comparisons",
            "itemListElement": [{"@type": "ListItem", "position": i + 1, "name": n, "url": u} for i, (n, u) in enumerate(links)]}
# Images
imgs = re.findall(r"!\[([^\]]+)\]\(img/([^)]+)\)\n\n\*(.+?)\*", s)
imageobjs = []
for alt, f, cap in imgs:
    imageobjs.append({"@type": "ImageObject", "@id": URL + "#img-" + f.split("-")[0], "contentUrl": IMG + f, "url": IMG + f,
                      "name": alt.split(":")[0][:110], "description": alt, "caption": plain(cap), "width": 1920, "height": 1080,
                      "encodingFormat": "image/png", "license": CC, "acquireLicensePage": CC, "creditText": "TDMM Research",
                      "creator": ORG, "copyrightHolder": ORG, "copyrightNotice": "© 2026 TDMM Ltd"})
A = L["tiers"]["All"]
dataset = {"@type": "Dataset", "@id": URL + "#dataset",
           "name": "TDMM CEX order book and DEX pool liquidity snapshot, 28 September 2026",
           "description": f"Gate USDT order books (500 levels a side) and DexScreener-reported DEX pools for {L['n']} tokens of $1M to $1B market cap, captured 18:33 to 18:36 UTC on 28 September 2026, with 30-day realised volatility from Gate daily candles. Measures: spread, two-sided depth within 2%, DEX pool value, constant-product depth, 24-hour DEX volume and fee coverage of loss-versus-rebalancing.",
           "creator": ORG, "publisher": ORG, "license": CC, "creditText": "TDMM Research", "temporalCoverage": "2026-09-28",
           "isAccessibleForFree": True, "keywords": ["crypto market maker", "liquidity provider", "DEX liquidity", "order book depth", "loss-versus-rebalancing"],
           "isBasedOn": [{"@type": "CreativeWork", "name": "Gate API v4 spot order book and candlesticks", "url": "https://www.gate.io/docs/developers/apiv4/"},
                         {"@type": "CreativeWork", "name": "DexScreener API", "url": "https://docs.dexscreener.com/api/reference"}],
           "variableMeasured": [
               {"@type": "PropertyValue", "name": "Median Gate spread", "value": round(A["median_gate_spread"], 1), "unitText": "basis points"},
               {"@type": "PropertyValue", "name": "Median Gate two-sided depth within 2%", "value": round(A["median_gate_two"]), "unitText": "USD"},
               {"@type": "PropertyValue", "name": "Median DEX pool value", "value": round(A["median_tvl"]), "unitText": "USD"},
               {"@type": "PropertyValue", "name": "Share of tokens whose pool fees covered arbitrage loss", "value": round(A["share_pools_cover_lvr"] * 100, 1), "unitText": "percent", "description": f"n = {A['n_lvr']} tokens, 0.3% fee assumption"},
               {"@type": "PropertyValue", "name": "Median pool capital, constant-product-dominated tokens", "value": round(A["cp_dom_median_tvl"]), "unitText": "USD", "description": f"n = {A['n_cp_dom']} tokens"},
               {"@type": "PropertyValue", "name": "Median depth within 2% delivered by those pools", "value": round(A["cp_dom_median_cp_depth"]), "unitText": "USD"}]}
person = {"@type": "Person", "@id": "https://tdmm.io/#vaibhav-singh", "name": "Vaibhav Singh", "worksFor": ORG,
          "url": "https://www.linkedin.com/in/vaibhav-singh-growth-hacker/", "sameAs": ["https://www.linkedin.com/in/vaibhav-singh-growth-hacker/"],
          "knowsAbout": ["crypto market making", "token liquidity", "liquidity provision"]}
org = {"@type": "Organization", "@id": "https://tdmm.io/#organization", "name": "TDMM", "legalName": "TDMM Ltd",
       "alternateName": ["TradeDog Market Maker", "TD Market Maker", "TDMM Market Maker"], "url": "https://tdmm.io/", "foundingDate": "2015",
       "logo": {"@type": "ImageObject", "@id": "https://tdmm.io/#logo", "url": "https://tdmm.io/images/logo.png", "contentUrl": "https://tdmm.io/images/logo.png", "width": 1514, "height": 540},
       "knowsAbout": ["crypto market making", "liquidity provision", "DEX market making", "CEX market making", "concentrated liquidity management", "token listing support", "crypto treasury management"],
       "sameAs": ["https://www.linkedin.com/company/tdmarketmaker/", "https://x.com/tdmarketmaker", "https://www.instagram.com/tdmarketmaker/",
                  "https://www.youtube.com/@tdmarketmaker", "https://www.binance.com/en-IN/square/profile/tdmarketmaker",
                  "https://coinmarketcap.com/community/profile/tdmarketmaker/", "https://www.reddit.com/user/TDMM_tdmarketmaker/",
                  "https://www.crunchbase.com/organization/tradedog-market-maker", "https://pitchbook.com/profiles/company/560286-55",
                  "https://www.rootdata.com/Projects/detail/TDMM?k=Njk1MA%3D%3D"]}
enrich = {"@id": URL + "#blogposting",
          "about": [{"@type": "Thing", "name": "Market maker (cryptocurrency)"}, {"@type": "Thing", "name": "Liquidity provider"}, {"@type": "Thing", "name": "Automated market maker"}],
          "mentions": [{"@id": URL + "#dataset"}], "hasPart": [{"@id": URL + "#faq"}, {"@id": URL + "#howto"}, {"@id": URL + "#glossary"}],
          "keywords": "crypto liquidity provider vs market maker which is better for token projects, crypto market maker vs liquidity provider, crypto liquidity provider vs market maker which is better for a new token projects",
          "image": [{"@id": o["@id"]} for o in imageobjs], "isAccessibleForFree": True}
graph = [enrich, faq, howto, dts, itemlist, dataset, org, person] + imageobjs
doc = {"@context": "https://schema.org", "@graph": graph}
# checks
ids = [n.get("@id") for n in graph if n.get("@id")]
assert len(ids) == len(set(ids)), "duplicate ids"
for n in graph:
    assert n.get("@type") not in ("BlogPosting", "Article", "WebPage", "WebSite", "BreadcrumbList")
body = plain(s)
for q in faq["mainEntity"]:
    assert q["name"] in body and q["acceptedAnswer"]["text"] in body, q["name"]
print("faq", len(faq["mainEntity"]), "steps", len(howto["step"]), "terms", len(dts["hasDefinedTerm"]), "related", len(links), "images", len(imageobjs), "nodes", len(graph))
open("out/final-schema-crypto-market-maker-vs-liquidity-provider.html", "w").write(
    '<script type="application/ld+json">\n' + json.dumps(doc, indent=1, ensure_ascii=False) + "\n</script>\n")
