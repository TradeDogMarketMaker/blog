import json, time, math, urllib.request, urllib.parse, sys
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 Chrome/124 Safari/537.36"
rows = json.load(open("pairs.json"))["rows"]
A, B = int(sys.argv[1]), int(sys.argv[2])
out = {}
for r in rows[A:B]:
    u = "https://api.gateio.ws/api/v4/spot/candlesticks?currency_pair=" + urllib.parse.quote(r['pair']) + "&interval=1d&limit=31"
    for t in range(3):
        try:
            d = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": UA}), timeout=15).read())
            closes = [float(c[2]) for c in d]
            rets = [math.log(closes[j] / closes[j - 1]) for j in range(1, len(closes)) if closes[j - 1] > 0 and closes[j] > 0]
            if len(rets) >= 20:
                mu = sum(rets) / len(rets)
                sd = math.sqrt(sum((x - mu) ** 2 for x in rets) / (len(rets) - 1))
                out[r["pair"]] = dict(vol=sd * math.sqrt(365), n=len(rets), last=d[-1][0])
            break
        except Exception as e:
            time.sleep(2)
json.dump(out, open(f"vol_{A}.json", "w"))
print("done", A, len(out))
