# Scripts

These scripts are MIT-licensed and need Python 3.10+ and `numpy`. The fetch scripts call public APIs: Gate API v4 and DexScreener.

| Script | Purpose |
|--------|---------|
| `fetch_pairs.py` | Selects Gate USDT pairs with an EVM or Solana contract, then pulls each Gate order book (500 levels) and every DexScreener pool. It writes `pairs.json`. Run with `python fetch_pairs.py 0` for the full universe. It needs `currencies.json` and `tickers.json` from Gate's `/spot/currencies` and `/spot/tickers`. |
| `fetch_vol2.py` | Computes 30-day realised volatility from Gate daily candles. Takes a start and end index, `python fetch_vol2.py 0 800`, and writes `vol_0.json`; merge the outputs into `vol.json`. |
| `analysis.py` | Builds `live.json`: the tier statistics, the pool vs book depth comparison, and pool fee coverage of loss-versus-rebalancing. |
| `model.py` | Builds `model.json`: the capital-for-depth model, range risk, loss-versus-rebalancing by volatility, the worked cost example and sell-off arithmetic. |
| `build_schema.py` | Builds the JSON-LD used on the original article. |

Live market data changes every second, so a re-run will not reproduce the 28 September 2026 snapshot exactly. The published figures are in `../data/`.
