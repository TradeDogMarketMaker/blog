"""TDMM study: where does a token's liquidity sit, CEX order book or DEX pool?
Sample Gate USDT pairs with an EVM/Solana contract, pull the Gate level-2 book and
the token's DEX pools from GeckoTerminal. Output: pairs.json (raw) for analysis.py."""
import json, time, random, math, sys, urllib.request, datetime

UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36"
def get(url, tries=4):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read())
        except Exception as e:
            if "429" in str(e):
                time.sleep(20 + 10 * i)
            else:
                time.sleep(3)
            err = e
    print("FAIL", url, err, file=sys.stderr)
    return None

CHAIN = {"ETH": "ethereum", "BSC": "bsc", "SOL": "solana", "BASEEVM": "base", "ARBEVM": "arbitrum",
         "MATIC": "polygon", "AVAX_C": "avalanche"}
STABLE = {"USDT", "USDC", "DAI", "FDUSD", "TUSD", "USDE", "USDD", "PYUSD", "USD1", "USDS", "FRAX", "BUSD",
          "EURC", "EURT", "USDP", "GUSD", "LUSD", "CRVUSD", "GHO", "USDX", "USDTB", "RLUSD", "USDG", "USD0"}
cur = {c["currency"]: c for c in json.load(open("currencies.json"))}
tick = {t["currency_pair"]: t for t in json.load(open("tickers.json"))}

cands = []
for pair, t in tick.items():
    if not pair.endswith("_USDT"):
        continue
    base = pair[:-5]
    c = cur.get(base)
    if not c or c.get("category") or c.get("delisted") or c.get("trade_disabled"):
        continue
    if base in STABLE or base.endswith(("3L", "3S", "5L", "5S")):
        continue
    try:
        mc = float(c.get("market_cap") or 0)
    except ValueError:
        mc = 0
    if not (1e6 <= mc <= 1e9):
        continue
    ch = [x for x in (c.get("chains") or []) if x["name"] in CHAIN and x.get("addr")]
    if not ch:
        continue
    # prefer the chain Gate lists as primary, else the first supported
    prim = [x for x in ch if x["name"] == c.get("chain")] or ch
    cands.append(dict(pair=pair, base=base, mc=mc, chain=prim[0]["name"], addr=prim[0]["addr"],
                      gate_vol=float(t.get("quote_volume") or 0)))

def tier(mc):
    return "<5M" if mc < 5e6 else "5-25M" if mc < 25e6 else "25-100M" if mc < 100e6 else "100M-1B"
random.seed(20260928)
by = {}
for c in cands:
    by.setdefault(tier(c["mc"]), []).append(c)
N = int(sys.argv[1]) if len(sys.argv) > 1 else 60
sample = []
for k, v in by.items():
    random.shuffle(v)
    sample += v[:N] if N > 0 else v
    print(k, "candidates", len(v), "sampled", min(N, len(v)), file=sys.stderr)

out = []
t0 = datetime.datetime.utcnow().isoformat()
for i, s in enumerate(sample):
    ob = get(f"https://api.gateio.ws/api/v4/spot/order_book?currency_pair={s['pair']}&limit=500")
    s["book_ts"] = datetime.datetime.utcnow().isoformat()
    s["bids"] = ob.get("bids") if ob else None
    s["asks"] = ob.get("asks") if ob else None
    net = CHAIN[s["chain"]]
    gp = get(f"https://api.dexscreener.com/token-pairs/v1/{net}/{s['addr']}")
    pools = []
    if isinstance(gp, list):
        for p in gp:
            is_base = (p.get("baseToken") or {}).get("address", "").lower() == s["addr"].lower()
            pools.append(dict(name=f"{p['baseToken']['symbol']}/{p['quoteToken']['symbol']}", dex=p.get("dexId"),
                              labels=p.get("labels") or [], quote=p["quoteToken"]["symbol"], is_base=is_base,
                              reserve=float((p.get("liquidity") or {}).get("usd") or 0),
                              vol24=float((p.get("volume") or {}).get("h24") or 0)))
    s["pools"] = pools
    s["ds_ok"] = gp is not None
    out.append(s)
    print(i, s["pair"], s["chain"], len(pools), file=sys.stderr)
    time.sleep(0.25)
json.dump(dict(started=t0, finished=datetime.datetime.utcnow().isoformat(), rows=out), open("pairs.json", "w"))
print("done", len(out), file=sys.stderr)
