---
layout: home
title: TDMM Research
---

Research on crypto market making and token liquidity from [TDMM (TradeDog Market Maker)](https://tdmm.io/). Charts and data are published under CC BY 4.0.
