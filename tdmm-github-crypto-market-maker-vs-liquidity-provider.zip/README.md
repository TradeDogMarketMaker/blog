# Crypto Market Maker vs Liquidity Provider: Which Is Better for a New Token Project?

[![Read on tdmm.io](https://img.shields.io/badge/Read%20on-tdmm.io-FFAD2F?style=flat-square)](https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/)
[![Charts and data: CC BY 4.0](https://img.shields.io/badge/charts%20%26%20data-CC%20BY%204.0-71A00D?style=flat-square)](https://creativecommons.org/licenses/by/4.0/)
[![Data as of 28 Sep 2026](https://img.shields.io/badge/data%20as%20of-28%20Sep%202026-000000?style=flat-square)](data/)

> **Originally published at [tdmm.io](https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/)** by TDMM (TradeDog Market Maker), 29 September 2026. This repository mirrors the article with its charts, data and scripts, so the findings can be checked and reused.


![Cover image for TDMM's guide to crypto market maker vs liquidity provider, comparing the capital, cost and obligations of each for a new token project.](images/00-cover-crypto-market-maker-vs-liquidity-provider.png)

*By Vaibhav Singh, TDMM (TradeDog Market Maker). Published 29 September 2026. Market data as of 28 September 2026.*

*Disclosure: TDMM provides both market making and liquidity provisioning to token projects. We say so at the top, publish our method and data, and state plainly where a passive liquidity provider is the better choice.*

## Contents

- [The short answer](#the-short-answer)
- [Key takeaways](#key-takeaways)
- [Crypto market maker vs liquidity provider at a glance](#crypto-market-maker-vs-liquidity-provider-at-a-glance)
- [What is a crypto liquidity provider?](#what-is-a-crypto-liquidity-provider)
- [What is a crypto market maker?](#what-is-a-crypto-market-maker)
- [Crypto liquidity provider vs market maker: which is better for token projects?](#crypto-liquidity-provider-vs-market-maker-which-is-better-for-token-projects)
- [Why a passive pool needs 100 times more capital for the same depth](#why-a-passive-pool-needs-100-times-more-capital-for-the-same-depth)
- [Concentrated liquidity needs a manager, which makes it market making](#concentrated-liquidity-needs-a-manager-which-makes-it-market-making)
- [The hidden cost of a passive pool: arbitrage](#the-hidden-cost-of-a-passive-pool-arbitrage)
- [What a passive pool does in a sell-off](#what-a-passive-pool-does-in-a-sell-off)
- [Where listed tokens' liquidity actually sits: TDMM's live measurement](#where-listed-tokens-liquidity-actually-sits-tdmms-live-measurement)
- [What exchanges mean when they say "liquidity provider"](#what-exchanges-mean-when-they-say-liquidity-provider)
- [How much does each option cost a new token project?](#how-much-does-each-option-cost-a-new-token-project)
- [Which is better for your token project? A decision matrix](#which-is-better-for-your-token-project-a-decision-matrix)
- [When you need both: one book, one reference price](#when-you-need-both-one-book-one-reference-price)
- [How to decide between a market maker and a liquidity provider in 30 days](#how-to-decide-between-a-market-maker-and-a-liquidity-provider-in-30-days)
- [Common mistakes when choosing between a market maker and a liquidity provider](#common-mistakes-when-choosing-between-a-market-maker-and-a-liquidity-provider)
- [Why TDMM is the go-to partner for market making and liquidity provision](#why-tdmm-is-the-go-to-partner-for-market-making-and-liquidity-provision)
- [Related TDMM guides and comparisons](#related-tdmm-guides-and-comparisons)
- [Frequently asked questions](#frequently-asked-questions)
- [Glossary](#glossary)
- [Sources](#sources)
- [Disclaimer](#disclaimer)
- [Data and method files](#data-and-method-files)
- [How to cite](#how-to-cite)
- [Licence](#licence)

---

## The short answer

For most new token projects, a market maker is the better choice as soon as the token trades on a centralised exchange or on more than one venue. A passive liquidity provider, meaning a seeded DEX pool, is enough only while the token lives in one pool with modest volume. A market maker contracts to quote both sides at an agreed spread, depth and uptime on every venue. A passive pool has no obligations. TDMM's model shows a full-range pool needs about 100 times the capital of an order book quote for the same depth, and at new-token volatility gives up about a third of its value a year to arbitrageurs before fees. Most projects end up needing both, run as one book.

## Key takeaways

- "Liquidity provider" means at least five different things in crypto: a passive pool depositor, a liquidity mining participant, a managed liquidity vault, a member of an exchange's rebate programme, and an institutional OTC desk. Only a market maker hired by the project owes the token a measurable service.
- Capital is the first difference. Holding $10,000 of depth on each side within 2% of the price takes about $2.01 million in a full-range constant-product pool, $98,000 in a concentrated range of plus or minus 10%, and about $20,000 of resting orders on an order book.
- Concentrated liquidity only works if someone moves the range. At the 166% annualised volatility TDMM measured for new listings, a plus or minus 10% range has a 66% chance of ending the week off the price if nobody touches it. Moving it is market making.
- Passive pools pay arbitrageurs. Using the loss-versus-rebalancing result of Milionis, Moallemi, Roughgarden and Zhang, a constant-product pool on a token with 166% volatility loses about 34.4% of its value a year to arbitrage before fees. Fees cover that only when daily volume runs above about 31% of the pool at a 0.3% fee.
- The historical record agrees. Bancor's study of 17 Uniswap v3 pools found $260.1 million of impermanent loss against $199.3 million of fees in 2021, with 49.5% of liquidity providers behind simply holding.
- TDMM measured 721 listed small and mid-cap tokens on Gate and in their DEX pools on 28 September 2026. Where pool liquidity was constant-product, a median $320,560 of pool capital delivered $3,203 of depth within 2%, about the same as the token's single Gate order book. On a generous fee assumption, only 50.5% of tokens' pools earned enough in fees to cover their arbitrage losses that day, and 42.0% below $5 million in market cap.
- On an exchange, "liquidity provider" is a rebate tier. Binance's Spot Liquidity Provider Program is graded on maker volume share and sets no spread or depth obligation for any single token. Binance's March 2026 guidelines instead ask issuers to disclose their market maker and ban profit-sharing deals.
- The better choice depends on where the token trades, not on which label sounds cheaper. DEX-only and early: a managed pool. First CEX listing onward: a market maker that runs the pool and the order book on one reference price, which is how TDMM works.

![Panel of nine numbers comparing crypto market makers and liquidity providers for new token projects, including the 100 times capital gap, 34.4% annual arbitrage cost for a passive pool at new-token volatility and TDMM's live order book and DEX pool measurements.](images/01-market-maker-vs-liquidity-provider-numbers.png)

*Nine numbers behind the market maker vs liquidity provider decision. Sources as dated in the panel.*

---

## Crypto market maker vs liquidity provider at a glance

![Side-by-side comparison table of a crypto market maker and a passive liquidity provider across where each works, how price is set, obligations, capital, cost, behaviour in a sell-off, CEX listings and best use.](images/03-market-maker-vs-liquidity-provider.png)

*The comparison most articles skip: capital, cost and behaviour under stress. Figures from TDMM's model in this article.*

| | Market maker | Liquidity provider (passive pool) |
|------------------|------------------------------|------------------------------|
| Where it works | CEX order books, DEX pools and perpetual markets | DEX pools only |
| How the price is set | Quotes updated continuously from one reference price | The pool's formula, applied to its own reserves |
| Obligation to the token | Spread, depth and uptime per venue, written into a contract | None |
| Capital for $10,000 a side within 2% | About $20,000 of resting orders, plus inventory to refill them | About $2.01 million in a full-range pool; about $98,000 in a plus or minus 10% range kept on the price |
| Cost to the project | A retainer, or a token loan whose call options are worth about 51% of the loan at new-listing volatility | Capital locked in the pool, plus about 34% of pool value a year lost to arbitrage before fees at 166% volatility |
| In a 50% sell-off | Widens, skews and hedges under an agreed stress clause | Spends 29.3% of its stablecoins buying the token on the way down |
| On a CEX listing | Covers the order book; Binance asks issuers to disclose who it is | Cannot serve an order book |
| Best for | Any token on a CEX, or on more than one venue | One DEX pool, early, before a CEX listing |

The rest of this article explains each row, shows the arithmetic, and adds TDMM's live measurements of where the liquidity of listed small and mid-cap tokens actually sits.

---

## What is a crypto liquidity provider?

A crypto liquidity provider is anyone who puts assets where others can trade against them: tokens deposited in a decentralised exchange (DEX) pool, or orders resting on an exchange. The term is broad because the activity is broad. When founders ask whether they need a market maker or a liquidity provider, they are usually comparing a contracted service with one of five quite different things.

![Table of five meanings of liquidity provider in crypto, passive pool LP, liquidity mining LP, managed liquidity vault, exchange LP programme member and institutional OTC liquidity provider, compared with an issuer-contracted market maker by what each does, its obligation to the token and who hires it.](images/02-what-liquidity-provider-means.png)

*Five things people mean by "liquidity provider". Only the last row is a service with obligations the token can measure.*

| Who | What they actually do | Obligation to your token | Who hires them |
|--------------|------------------------------|--------------------|--------------|
| Passive pool LP | Deposits a token pair into an automated market maker (AMM) pool; the pool formula sets the price | None; can withdraw at any time | Nobody. Often the project's own treasury, or traders chasing fees |
| Liquidity mining LP | A pool LP paid in the project's token to stay in the pool | Only while rewards are paid | The project, through token emissions |
| Managed liquidity vault | Moves concentrated price ranges on pools the issuer owns | Strategy rules, and KPIs if agreed | The project |
| Exchange liquidity provider programme member | Quotes many pairs on an exchange to earn maker rebates | To the exchange, measured on volume share, not to any one token | The exchange |
| Institutional OTC liquidity provider | Streams prices or answers quote requests for brokers, funds and exchanges | To its clients, trade by trade | Institutions |
| Market maker, contracted by the issuer | Quotes both sides on every venue, manages inventory, keeps one reference price and reports | Spread, depth and uptime per venue, in a contract | The project |

The first two are what most retail explainers mean. A **passive pool LP** deposits two assets, typically the new token and a stablecoin or ETH, into a pool on Uniswap, PancakeSwap, Raydium or Aerodrome, and earns a share of swap fees. The pool's formula sets the price from the ratio of its reserves. Nobody is obliged to do anything, and the deposit can be withdrawn at any moment. For a new token the first LP is almost always the project itself, seeding the pool from its treasury. A **liquidity mining** programme pays other people, in the project's own token, to add to that pool.

The third is professional. A **managed liquidity vault** keeps concentrated-liquidity ranges positioned around the price on pools the issuer owns. That is DEX market making by another name, and it is the service firms such as Arrakis and TDMM sell for DEX-only tokens.

The fourth and fifth are institutional. When an exchange says "liquidity provider", it usually means a member of its rebate programme, a firm quoting hundreds of pairs for a lower fee. When a bank or broker says it, it usually means an OTC desk such as B2C2, Cumberland or Flow Traders, which prices large trades for clients. Neither owes a specific token anything.

The overlap is why AI answers and search results on this question tend to talk past each other. Google's AI Overview for "crypto market maker vs liquidity provider" on 28 September 2026 defined LPs as retail users staking assets on Uniswap and named Wintermute and Cumberland as examples of market makers. That is true, and it does not help a founder decide what to hire. TDMM's explainer on [what liquidity is](https://tdmm.io/insights/blog/what-is-liquidity/) covers the underlying idea.

---

## What is a crypto market maker?

A crypto market maker is a firm that continuously posts buy orders (bids) and sell orders (offers) for a token on one or more venues, holding inventory on both sides, so anyone can trade at a visible price at any moment. When a token project hires one, the relationship is a contract with measurable terms: the maximum spread between the bid and the offer, the minimum depth within 1% or 2% of the price, and the share of time quotes must be live, set for each venue.

A market maker works on centralised exchange (CEX) order books, where it places and cancels limit orders thousands of times a minute, and increasingly on DEXs, where it manages concentrated-liquidity ranges or runs its own onchain quoting engine. What makes it a market maker rather than a liquidity provider is the obligation and the view. It is obliged to quote both sides to a standard. It holds a view of the one reference price across every venue, so its quotes move when the market moves anywhere, not only when someone trades against it. And it reports what it delivered. TDMM's guide to [how market making works in crypto exchanges](https://tdmm.io/insights/blog/how-does-market-making-work-in-crypto-exchanges/) covers the mechanics.

### Is a market maker a liquidity provider?

Yes. Every market maker provides liquidity, but most liquidity providers are not market makers. The difference is the contract. A liquidity provider supplies assets with no promise about how the market will look. A market maker promises a spread, a depth and an uptime, on every venue it covers, and can be held to it. For a token project, that promise is the product.

---

## Crypto liquidity provider vs market maker: which is better for token projects?

For a new token project, the answer turns on one question: where will the token trade in the next six months?

If the token trades only in one DEX pool, volume is modest and there is no centralised exchange listing on the horizon, a well-seeded pool with its range managed is usually enough. Paying a full market making retainer to look after one pool is money better spent elsewhere, and TDMM says so to projects in that position.

Once the token lists on a centralised exchange, the question answers itself. An order book is empty until someone quotes it, and a pool cannot quote an order book. From that point there are two markets, the pool and the book, with two prices that drift apart unless one desk holds them on a single reference price. That is market making, and it is why a market maker is the better choice for almost every token project from its first CEX listing onward.

Between those two points sits the case that decides most budgets: a token on several pools or chains, or about to list. Here the useful comparison is not "market maker or liquidity provider" but "passive liquidity or managed liquidity". The arithmetic in the next four sections shows why passive liquidity is the expensive option for a volatile new token, even before a CEX is involved.

---

## Why a passive pool needs 100 times more capital for the same depth

Depth is the dollar value a token can absorb before its price moves by a set amount. CoinMarketCap and CoinGecko display it at 2% of the mid price, so it is the number an exchange listing team and a token's community will look at.

In a constant-product pool, the Uniswap v2 design that most launchpads still graduate tokens into, lifting the price by 2% takes about 0.995% of the pool's stablecoin side. So $10,000 of buying capacity within 2% requires a stablecoin reserve of about $1.005 million, and a pool worth about $2.01 million once the token side is counted. On an order book, the same $10,000 on each side is $20,000 of resting orders.

![Bar chart on a log scale of capital needed to hold $10,000 of depth per side within 2% of the price: $2.01 million in a full-range pool, $479,000 in a plus or minus 50% concentrated range, $241,000 at plus or minus 25%, $98,000 at plus or minus 10%, $50,000 at plus or minus 5%, and $20,000 of resting orders for an order book market maker.](images/04-capital-needed-for-depth.png)

*The capital gap between passive and active liquidity. Source: TDMM model, 28 Sep 2026.*

| Liquidity design | Capital for $10,000 a side within 2% | Multiple of the order book |
|--------------------|--------------------|----------|
| Full-range pool (Uniswap v2 style) | $2,009,950 | 100.5x |
| Concentrated, plus or minus 50% range | $478,767 | 23.9x |
| Concentrated, plus or minus 25% range | $240,739 | 12.0x |
| Concentrated, plus or minus 10% range | $98,341 | 4.9x |
| Concentrated, plus or minus 5% range | $49,666 | 2.5x |
| Order book market maker | $20,000 of resting orders | 1.0x |

Concentrated liquidity, introduced by Uniswap v3 in 2021 and now standard on PancakeSwap, Aerodrome, Raydium and Orca, narrows the gap by placing all of the pool's capital inside a chosen price range. Uniswap Labs described the design as up to 4,000 times more capital efficient than v2 at launch. For a range running from 10% below the current price to 10% above it, the same depth needs about one twentieth of the capital of a full-range pool.

Two caveats keep the comparison honest. The order book figure is resting inventory only; a market maker holds more than that so it can refill quotes after trades, and it has to hold it on every venue it quotes. And the concentrated figures only hold while the price stays inside the range. That second condition is where passive liquidity breaks down for a new token.

---

## Concentrated liquidity needs a manager, which makes it market making

A concentrated range quotes nothing once the price leaves it. For a stable pair that rarely matters. For a new token it is the normal state of affairs within days.

TDMM measured the annualised volatility of 750 new listings on Gate at a median of 166%, with quartiles of 128% and 218%, in its study of [how market making works after a token listing](https://tdmm.io/insights/blog/how-market-making-works-after-a-token-listing/). At 166% a year, a token's typical daily move is about 8.7%. Feeding that into a standard lognormal model gives the chance that the price ends a period outside a range nobody has moved.

![Grouped bar chart of the probability that a new token's price ends outside a concentrated-liquidity range at 166% volatility: for a plus or minus 50% range 0% after 1 day, 4% after 7 days and 27% after 30 days; plus or minus 25% range 1%, 27% and 59%; plus or minus 10% range 25%, 66% and 83%; plus or minus 5% range 56%, 83% and 92%.](images/05-concentrated-range-risk.png)

*A tight range on a new token is out of position within days. Source: TDMM model, 28 Sep 2026.*

| Range around the price | Out of range after 1 day | After 7 days | After 30 days |
|-------------|--------|--------|--------|
| Plus or minus 50% | 0% | 4% | 27% |
| Plus or minus 25% | 1% | 27% | 59% |
| Plus or minus 10% | 25% | 66% | 83% |
| Plus or minus 5% | 56% | 83% | 92% |

*Probability the price ends the period outside the range, at 166% annualised volatility, no drift. The chance it leaves at some point during the period is higher.*

This is the trade-off in one table. The ranges that make pool liquidity affordable are exactly the ones that need moving every few days, sometimes every few hours. Moving them well means watching the token's price on every venue, deciding when to re-centre and how wide to set the new range, paying gas, and accepting that each move locks in the loss from the old position. That is the work of a DEX market maker. A project that seeds a concentrated pool and walks away has chosen the capital efficiency of active liquidity with the management of passive liquidity, and within a week will have neither.

---

## The hidden cost of a passive pool: arbitrage

The largest cost of pool liquidity does not appear on any invoice. Every time the token's price moves on another venue, the pool is quoting a stale price until an arbitrageur trades against it and brings it back into line. The arbitrageur's profit is the pool's loss.

Jason Milionis, Ciamac Moallemi, Tim Roughgarden and Anthony Lee Zhang formalised this in 2022 as loss-versus-rebalancing (LVR): what a pool loses compared with a trader who makes the same trades at market prices. For a constant-product pool the rate has a simple closed form. The pool loses volatility squared divided by eight, per unit of time, as a share of its value.

![Bar chart of annual loss-versus-rebalancing as a share of a constant-product pool by token volatility: 2.5% at 45% volatility, 8.0% at 80%, 12.5% at 100%, 20.5% at 128%, 34.4% at the 166% median for new listings and 59.4% at 218%.](images/06-loss-versus-rebalancing-by-volatility.png)

*What a passive pool loses to arbitrageurs each year, before fees. Source: TDMM calculation using Milionis et al. (2022).*

| Token volatility (annualised) | Annual arbitrage loss, share of pool value, before fees |
|--------------------|--------------------|
| 45%, Bitcoin-like | 2.5% |
| 80%, large-cap altcoin | 8.0% |
| 100% | 12.5% |
| 128%, new listing lower quartile | 20.5% |
| 166%, new listing median | 34.4% |
| 218%, new listing upper quartile | 59.4% |

Because the cost rises with the square of volatility, it barely matters for a Bitcoin pool and dominates for a new token. At 166% volatility a passive pool gives up about a third of its value a year to arbitrageurs. Swap fees offset part of that, and the more often a pool trades the more they offset. At a 0.3% fee, a pool breaks even against arbitrage only when its daily volume runs above about 31% of its value, every day.

One further detail matters for founders comparing designs. The arbitrage loss scales with the amount of liquidity sitting near the price, not with the capital deposited. A concentrated pool offering the same depth as a full-range pool pays the same arbitrage bill while it stays in range. Concentration saves capital. It does not make the pool any less stale.

An active market maker faces the same traders, but it is not quoting a stale price. It reprices from the reference price across every venue, widens when volatility rises, skews its quotes when inventory builds up on one side, and hedges. It still loses some trades to better-informed flow; that is the cost of being in the market. The difference is that it can do something about it, and a pool cannot.

### What the Uniswap v3 record shows

The best-known empirical test of passive LP returns came from Bancor's research team. Stefan Loesch, Nate Hindman, Mark Richardson and Nicholas Welch studied 17 Uniswap v3 pools holding 43% of the protocol's value locked, from its launch on 5 May 2021 to 20 September 2021.

![Bar chart comparing $199.3 million of fees earned with $260.1 million of impermanent loss across 17 Uniswap v3 pools from May to September 2021, with tiles showing liquidity providers $60.8 million behind holding and 49.5% of liquidity providers with negative returns.](images/11-uniswap-v3-lp-returns.png)

*Fees did not cover the loss. Source: Loesch et al., "Impermanent Loss in Uniswap v3", 17 Nov 2021.*

The pools earned $199.3 million in fees and suffered $260.1 million of impermanent loss, leaving liquidity providers $60.8 million worse off than if they had simply held the two assets. Half of them, 49.5%, had negative returns on that basis. The study covers one protocol version in one period, much of it on large, liquid pairs. New tokens are more volatile, which on the LVR arithmetic above makes the result worse, not better.

---

## What a passive pool does in a sell-off

Every market maker contract worth signing says what happens in a crash: whether quotes widen, pause or stay, how fast they return, and how that is reported. A passive pool has no such clause. It does exactly one thing when the token falls. It buys.

In a constant-product pool the stablecoin reserve scales with the square root of the price ratio. When the token halves, the pool has spent 29.3% of its stablecoins buying it. When the token falls 80%, 55.3% is gone. At minus 90%, 68.4%.

![Stacked horizontal bar chart of a full-range pool's stablecoin side in a sell-off: 29.3% spent buying the token at a 50% price fall, 55.3% at an 80% fall and 68.4% at a 90% fall.](images/12-pool-stablecoins-in-a-selloff.png)

*A passive pool is a standing buy order all the way down. Source: TDMM calculation, 28 Sep 2026.*

| Token price move | Pool's stablecoins spent buying the token | Stablecoins left | Loss against holding |
|---------|--------|--------|--------|
| Minus 50% | 29.3% | 70.7% | 5.7% |
| Minus 80% | 55.3% | 44.7% | 25.5% |
| Minus 90% | 68.4% | 31.6% | 42.5% |
| Plus 100% | Pool has sold 29.3% of its tokens | | 5.7% |
| Plus 400% | Pool has sold 55.3% of its tokens | | 25.5% |

When the pool belongs to the project's treasury, that is the treasury converting its stablecoin runway into its own falling token, automatically and without a vote. Sometimes a project wants to defend the price that way. It should be a decision, made with a budget and a limit, not a side effect of how the pool was built. The same arithmetic runs in reverse on the way up: a passive pool sells the treasury's tokens into every rally. TDMM's [treasury management guide](https://tdmm.io/insights/blog/crypto-treasury-management-best-practices-2026/) covers why treasury and liquidity have to be managed as one book.

---

## Where listed tokens' liquidity actually sits: TDMM's live measurement

Models are only useful if the market behaves like them. So TDMM measured it.

**Method.** Between 18:33 and 18:36 UTC on 28 September 2026, TDMM captured the order book of every eligible USDT pair on Gate, 500 price levels a side, and pulled every DEX pool for the same tokens from DexScreener's public API. The sample covers tokens with a Gate-reported market capitalisation between $1 million and $1 billion and a contract on Ethereum, BNB Chain, Solana, Base, Arbitrum, Polygon or Avalanche, with stablecoins, leveraged tokens and tokenised stocks and commodities removed. That left 721 tokens with a two-sided book. We then took 30 days of Gate daily candles for each token to measure its realised volatility. Gate was chosen because it lists more small and mid-cap tokens than almost any other major exchange, and the tokens it lists are the ones whose founders face this decision.

![Table of liquidity for 721 listed tokens by market cap tier, showing median Gate spread and depth within 2%, the share of Gate books thin on one side, median DEX pool value, the share of tokens with under $10,000 in DEX pools and the share whose pool fees covered arbitrage.](images/10-where-token-liquidity-sits-live.png)

*Where the liquidity of listed small and mid-cap tokens sits. Source: TDMM snapshot, 28 Sep 2026.*

| Market cap tier | Tokens | Median Gate spread | Median Gate depth within 2% | Gate book thin on one side | Median DEX pool value | Tokens with under $10k in DEX pools | Pool fees covered arbitrage |
|-----------|-----|---------|---------|---------|---------|---------|---------|
| Under $5M | 173 | 56.2 bps | $1,147 | 97.7% | $39,938 | 32.9% | 42.0% |
| $5M to $25M | 272 | 31.6 bps | $4,790 | 87.5% | $161,892 | 26.8% | 46.5% |
| $25M to $100M | 184 | 19.3 bps | $12,333 | 69.0% | $319,219 | 14.1% | 55.9% |
| $100M to $1B | 92 | 13.0 bps | $35,340 | 42.4% | $1,240,138 | 8.7% | 64.4% |
| All tokens | 721 | 28.5 bps | $5,523 | 79.5% | $169,645 | 22.7% | 50.5% |

*"Thin on one side" means under $10,000 within 2% of the mid price on the thinner side of the Gate book. Pool value is the sum of DexScreener-reported liquidity across all of a token's pools. The last column covers the 647 tokens with a pool and volatility data.*

Three findings stand out.

**Pools hold the capital; order books deliver the depth per dollar.** Across the 163 tokens whose DEX liquidity sits at least 90% in constant-product pools, where the 2% depth can be calculated exactly, the median token had $320,560 in its pools. That capital delivered $3,203 of two-sided depth within 2%. The same tokens' single Gate order book showed a median $2,577. In other words, a third of a million dollars of pool capital bought roughly the depth of one small exchange order book, which is the 100-to-1 ratio the model predicts. The pools were deeper than the Gate book for 56.4% of those tokens, so the pool matters. It is just expensive depth.

![Horizontal bar chart on a log scale for 163 tokens with mainly constant-product DEX liquidity: median capital in DEX pools $320,560, depth those pools deliver within 2% $3,203, and depth on one Gate order book within 2% $2,577.](images/08-pool-capital-vs-depth-live.png)

*Measured, not modelled: pool capital against the depth it delivers. Source: TDMM snapshot, 28 Sep 2026.*

**About half of the pools did not earn their keep.** For each token with a pool, TDMM compared the fees its pools earned over the previous 24 hours with the arbitrage loss the LVR formula implies at that token's own 30-day volatility. The median token in the sample had a realised volatility of 88%, well below a new listing's. On a generous assumption that every pool charges a 0.3% fee, fee income covered the arbitrage loss for 50.5% of tokens. Below $5 million in market cap it was 42.0%. Above $100 million it was 64.4%.

![Bar chart of the share of tokens whose DEX pool fees covered their estimated arbitrage loss over 24 hours, on a 0.3% fee assumption: 42% under $5M, 47% at $5M to $25M, 56% at $25M to $100M, 64% at $100M to $1B and 51% across all tokens.](images/09-pool-fees-vs-arbitrage-live.png)

*Passive pools pay for themselves on larger, busier tokens and struggle on small ones. Source: TDMM snapshot, 28 Sep 2026.*

That gradient is the honest answer to the question in this article. Passive pool liquidity works best on larger tokens with steady volume, and worst on exactly the small, volatile, newly listed tokens whose founders are most tempted by it, because it looks free.

**Many listed tokens barely have a pool at all.** 22.7% of the tokens had less than $10,000 in DEX pools in total, and 43.0% had less than $100,000. At the same time, 79.5% of their Gate books could not absorb a $10,000 order on their thinner side within 2%, in line with the 78.6% TDMM found across 2,702 Gate and MEXC books two days earlier. For most listed small caps, neither side of the market is deep. A market maker's job is to fix the book and manage the pool together, because a trader sees both.

Several caveats apply. This is one centralised exchange and one data provider, captured in a single three-minute window, and DEX volume and liquidity are as DexScreener reports them, which can include automated trading. The fee comparison assumes a 0.3% fee tier; many concentrated pools charge 1% and some charge 0.05%. For concentrated pools the LVR formula understates the loss per dollar of capital, which makes the comparison generous to pools. Market capitalisations come from Gate's API. None of this changes the direction of the findings.

---

## What exchanges mean when they say "liquidity provider"

On a centralised exchange, "liquidity provider" usually names a fee tier. That matters for founders, because a listing team asking "who is your liquidity provider?" is asking something quite different from the exchange's own LP programme.

![Three cards describing Binance's Spot Liquidity Provider Program, its Altcoin LiquidityBoost programme and its March 2026 market maker guidelines for issuers.](images/14-exchange-liquidity-provider-programmes.png)

*Exchange LP programmes reward maker volume. Your token's service level comes from your own contract.*

Binance's Spot Liquidity Provider Program is the clearest example. Its tiers are set mainly by each firm's share of weekly maker volume, and the rewards are lower maker fees, rebates in the upper tiers and higher API limits. The September 2024 update let firms reach Tier 1 with a 0.05% share of weekly maker volume or $25 million of it, and cut the top-tier rebate from 0.01% to 0.008%. The published terms contain no spread, depth or uptime obligation for any particular token. In June 2025 Binance added an Altcoin LiquidityBoost programme for smaller liquidity providers on 18 altcoins, paying rebates of 0.5 to 1 basis point to firms supplying 0.5% to 1% of maker volume in those pairs, with at least $20 million of 30-day volume on Binance or other venues.

Programmes like these are good for an exchange's overall market quality, and a market maker that belongs to one can quote a token more cheaply. They are not a service to the token. A firm that earns its rebate across hundreds of pairs owes your pair nothing in particular.

What Binance asks of issuers points the other way. Its "Market Maker Red Flags and Guidelines" post of 25 March 2026 tells token projects to report their market maker's identity, legal entity and contract terms to the listing platform, to define how any loaned tokens may be used, and not to enter profit-sharing or guaranteed-profit arrangements with their market maker. It lists six red flags, including one-sided trading, volume that does not match price behaviour and volume out of proportion to order book depth. The exchange expects a named counterparty with a written contract, which is a market maker relationship, not a pool.

On the largest venues, then, nobody sets a service level for your token unless your own contract does. TDMM's [post-listing market making study](https://tdmm.io/insights/blog/how-market-making-works-after-a-token-listing/) sets out what exchanges now expect in more detail.

---

## How much does each option cost a new token project?

Cost comparisons between market makers and liquidity providers usually stop at "market makers charge fees, liquidity pools are free". That misses the three largest costs: the capital a pool locks up, the arbitrage it pays, and the option value a "free" market maker takes. The worked example below puts all of them in the same units.

**The target.** A token worth between $5 million and $25 million that wants top-quartile depth for its size. TDMM's benchmark of 2,702 live order books on Gate and MEXC on 26 September 2026 put that at $17,546 of two-sided depth within 2% of the price. Volatility is 166%, the median for new listings.

![Table comparing five ways to give a $5M to $25M token top-quartile depth: a passive full-range pool, a self-managed concentrated range, liquidity mining, a market maker on retainer and a market maker on a token loan with call options, with capital tied up, 12-month cost and what each delivers.](images/07-cost-of-depth-worked-example.png)

*The same depth, five ways. Illustrative arithmetic on stated assumptions, not a quote.*

| Option | Capital tied up | Cost over 12 months | What you get |
|--------------|------------------|------------------------|--------------|
| Passive full-range pool | About $1.76 million of pool value, half of it stablecoins | About $607,000 lost to arbitrage before fees; fees cover it only above about $555,000 of daily volume at a 0.3% fee | Depth on one DEX pool |
| Concentrated plus or minus 10% range, self-managed | About $86,000 of pool value | The same ~$607,000 of arbitrage while in range, plus gas; a 66% chance the range is off the price after a week if left alone | Depth on one pool, while in range |
| Liquidity mining | Third-party capital | Emissions paid in the project's own token; the capital leaves when rewards stop | Rented depth on one pool |
| Market maker on retainer | About $17,500 of resting orders per venue, from inventory the project lends and gets back | $36,000 to $180,000 in fees at vendor-published bands of $3,000 to $15,000 a month | Contracted spread, depth and uptime on every venue, CEX and DEX |
| Market maker on a token loan with call options | A loan of, for example, 1.5% of supply | No cash, but at 166% volatility the options are worth about 51% of the loan's value | The same service, paid for in upside |

Three things stand out.

**The passive pool is the most expensive option in the table.** It needs roughly $1.76 million of capital, half of it stablecoins the project may need for runway, and it pays about $607,000 a year to arbitrageurs unless its daily volume stays above roughly $555,000. For a token of this size that is a high bar: TDMM's live data in the next section shows how far most small-cap pools sit below it.

**Liquidity mining rents depth, it does not buy it.** Gauntlet's June 2023 analysis of a Uniswap liquidity mining experiment across five pools found a lasting effect on liquidity and volume in two of them, a 40% success rate, and results it could not attribute in the other three. Emissions paid in a new token are also supply released into a thin market.

**The "free" market maker has a price too.** Under a token loan with call options no cash changes hands, which is why it is popular. TDMM priced a standard structure, 1.5% of supply with three call tranches at 1.25, 1.5 and 2 times the reference price over twelve months, at 51% of the loan's value at 166% volatility, or $764,723 on a $1.5 million loan. A retainer costs cash up front and leaves the upside with the project. Which is cheaper depends on how the token performs; the full comparison is in TDMM's [post-listing study](https://tdmm.io/insights/blog/how-market-making-works-after-a-token-listing/).

Published market maker pricing is thin and comes mostly from the firms selling it. OpenLiquid, a market making vendor, put monthly fees at $3,000 to $5,000 for budget providers, $5,000 to $10,000 for mid-tier firms and $10,000 to $15,000 or more for premium ones in a December 2025 guide. A price list Caladan published in April 2024, covering nine unnamed retainer-based market makers as of January 2024, ranged from $1,000 to $7,000 per exchange per month, each with a 15% to 20% performance carry. A founder listing on Binance should check whether a carry counts as the profit-sharing its March 2026 guidelines prohibit.

---

## Which is better for your token project? A decision matrix

The right answer changes as a token moves from launch to listing to maturity. Most projects move down this table, and the service they need changes with them.

![Decision matrix matching token project stages to what they need: launchpad or bonding curve, DEX only with one pool, DEX only with several pools, first CEX listing, several CEXs and DEXs, and unlocks or treasury exits.](images/13-market-maker-or-liquidity-provider-decision-matrix.png)

*Match the service to where the token trades. TDMM publishes this article and provides both services.*

| Stage | Where trading happens | What the project needs | TDMM's call |
|---------------|------------------|------------------------|------------------|
| Launchpad or bonding curve | Pump.fun, four.meme and similar | The curve handles price discovery; plan the graduation | Neither yet. Line up pool management for the day the token graduates |
| DEX only, one main pool | Uniswap, PancakeSwap, Raydium, Aerodrome | A seeded pool with its range managed | A liquidity provider, managed as DEX market making |
| DEX only, several pools or chains | Two or more pools, or two or more chains | One price across pools, with arbitrage kept in check | A DEX market maker |
| First CEX listing | One centralised exchange plus the DEX pool | Quotes on the order book from the first second, with pool and book on one price | A market maker covering CEX and DEX |
| Several CEXs, DEXs and perpetuals | Many venues | Cross-exchange quoting, inventory and reporting per venue | A full-lifecycle market maker |
| Unlocks, treasury sales, exits | Every venue, plus OTC | Execution, block liquidity and hedging on one book | A market maker, plus OTC liquidity |

Three cases deserve a closer look.

**Memecoins and fair launches.** A memecoin born on a bonding curve does not need anyone for price discovery; the crowd does that. It needs help at graduation, when the curve's proceeds seed a pool that is suddenly the token's only market, and again when a centralised exchange lists it and the pool and the book start to disagree. CoinGecko Research found that about 1% of the 18.67 million tokens created on Pump.fun between January 2024 and June 2026 graduated to an external DEX, so the teams that reach that point should plan for it. TDMM's shortlist of the [best market makers for new token launches](https://tdmm.io/best/market-makers-for-new-token-launches) covers the options.

**DEX-only tokens with real volume.** A token that trades several hundred thousand dollars a day across pools on two chains is already doing a market maker's job badly if nobody is keeping those pools on one price. The arbitrage between them is paid by the pools, which usually means by the treasury. See TDMM's list of the [best DEX market makers](https://tdmm.io/best/dex-market-makers).

**The first CEX listing.** This is the point where "liquidity provider or market maker" stops being a real choice. The listing brings an empty order book, an exchange that wants to know who is quoting it, and a DEX pool that now has a second price to track. TDMM's guide to [cross exchange market making](https://tdmm.io/insights/blog/what-is-cross-exchange-market-making/) explains why that second price is where most new tokens leak value.

---

## When you need both: one book, one reference price

Most token projects end up with both kinds of liquidity: pools on one or more DEXs, and order books on one or more centralised exchanges. The mistake is buying them from different places and running them separately.

Two markets that are not connected are two prices. When the CEX book is tighter than the pool, arbitrageurs buy on one and sell on the other, and the pool's LVR bill goes up. When the pool is out of range and the book is quoting, the token's DexScreener chart and its CoinMarketCap page tell different stories. When a large seller hits the pool, the book should move too, and it only does if the same desk sees both.

Running both as one book means one reference price for every venue, one inventory view across pools and order books, and one risk limit for the whole position. Pool ranges are set from the same price the order book quotes around. Inventory moves between venues as flow demands, rather than sitting idle in one while another runs dry. Stress rules apply everywhere at once. Reporting shows spread, depth and uptime for each order book alongside range position and depth for each pool, so the treasury sees one market rather than several.

This is the model TDMM uses. It is also why the question in this article's title has a slightly unsatisfying answer for most projects: the better choice is a partner that can do both, and knows when a project needs only one.

---

## How to decide between a market maker and a liquidity provider in 30 days

**Days 1 to 5: map the venues.** List every venue the token trades on or will list on within six months, CEX and DEX, with the chain for each pool. If the list includes a centralised exchange or more than one pool, plan for a market maker. If it is one pool, plan for managed pool liquidity and revisit at the first listing.

**Days 6 to 10: set the target.** Take your market cap tier from TDMM's benchmark and write down the top-quartile spread and depth within 2%. For a token between $5 million and $25 million, that is 17.1 basis points or tighter and $17,546 of two-sided depth. Decide how much capital the treasury can commit and how much of that can be stablecoins.

**Days 11 to 15: price every option in dollars.** For a pool, work out the capital needed for the target depth and the arbitrage cost at your token's volatility, and compare it with realistic fee income. For a market maker, get the retainer in writing and ask for the option value of any token loan in dollars. For liquidity mining, value the emissions at today's price and ask what happens when they stop.

**Days 16 to 22: shortlist and test.** Send the same written brief to three providers. Ask which of your venues each can cover today, what spread, depth and uptime it will commit to per venue, how it manages pool ranges, what it does in a 30% move, how it reports, and whether its identity and terms can be disclosed to every exchange. Check each firm against DOJ, SEC and exchange enforcement records.

**Days 23 to 30: sign, disclose and fund.** Write the KPIs, the reporting cadence, the stress clause and the permitted use of any loaned tokens into the contract. Disclose the market maker to the exchanges you list on, as Binance's March 2026 guidelines ask. Fund inventory on every venue and seed the pools at the ranges agreed, before the first trade.

![Seven question cards for deciding between a market maker and a liquidity provider, covering CEX plans, number of venues, capital, pool volume, range management, sell-off behaviour and cost in dollars.](images/16-seven-questions-market-maker-or-liquidity-provider.png)

*Seven questions that settle the choice. Checklist: TDMM.*

---

## Common mistakes when choosing between a market maker and a liquidity provider

**Treating a seeded pool as a liquidity strategy.** A pool is infrastructure. Without someone managing its range and its relationship to other venues, it quotes stale prices, pays arbitrageurs and buys the token all the way down in a sell-off.

**Choosing concentrated liquidity and then leaving it alone.** The capital saving only exists while the range sits on the price. At new-token volatility, an unmanaged plus or minus 10% range has a 66% chance of ending a week out of position.

**Counting liquidity mining as depth.** Emissions rent capital for as long as they are paid. They also add sell pressure in the token being supported.

**Believing the exchange's LP programme covers your token.** Exchange programmes are graded on volume across many pairs. They set no service level for yours.

**Comparing a retainer with "free".** A token loan with call options is paid for in upside. Price it before comparing it with a fee.

**Running pools and books with different providers.** Two providers means two prices, two inventories and nobody responsible for the gap between them.

**Paying for volume.** Volume without depth is what Binance's red flags describe and what US prosecutors have charged. Measure any provider on spread, depth and uptime, which anyone can check from public data.

---

## Why TDMM is the go-to partner for market making and liquidity provision

![TDMM coverage panel: active since 2015, $10B+ traded, 100+ CEX and DEX integrations, 200+ markets and 24/7 operations, with centralised exchanges, DEXs and launchpads, chains and services listed.](images/17-tdmm-market-making-and-liquidity-coverage.png)

*Order books, DEX pools and launchpads on one desk. Source: TDMM company information.*

TDMM (TradeDog Market Maker) is the market making and token market management arm of TradeDog Group. It has been active in crypto markets since 2015, reports more than $10 billion in trading volume, and runs more than 100 CEX and DEX integrations and more than 200 markets, with 24-hour operations staffed by a team of over thirty people on five continents.

The reason TDMM is the natural first call on this question is that it does not have to sell one answer. It provides market making and liquidity provisioning as one service. On the DEX side it manages pools on Uniswap, PancakeSwap, SushiSwap, Raydium, Orca, QuickSwap and PulseX, and handles launchpad graduations including four.meme, across Ethereum, BNB Chain, Solana, Base, Polygon, Avalanche and PulseChain. On the CEX side it quotes on Binance, OKX, Bybit, Gate, KuCoin, Bitget, MEXC, HTX and more than ninety other exchanges. Pools and books run on one reference price, from one inventory, under one set of risk limits.

For a project that needs only managed pool liquidity, TDMM says so and scopes the mandate to that. For a project heading to its first centralised listing, it sets the pool ranges and the order book quotes from the same price from the first second. For a project with unlocks, treasury sales or an exit ahead, the same desk handles [treasury management](https://tdmm.io/insights/blog/crypto-treasury-management-best-practices-2026/), yield on idle inventory and [exit management](https://tdmm.io/insights/blog/how-to-manage-token-exit-strategy-professionally/) on the same book.

Every mandate is written in units a founder can check: spread, depth and uptime per order book; range position and depth per pool; reporting on a cadence the treasury can verify against public data. TDMM runs a retainer where the project wants to keep its upside and a loan structure where it would rather pay in optionality, prices any option value in dollars before signing, and drafts the agreement so it can be disclosed to every exchange. Token loans are structured so that treasury inventory is never the source of selling.

TDMM does not promise a price or a volume number. It promises a two-sided market at an agreed standard, on every venue, pool or order book, for the whole life of the token.

---

## Related TDMM guides and comparisons

### Use-case rankings

| Guide | Read it if you are |
|----------------------------|------------------------------------------|
| [Top liquidity providers for crypto projects](https://tdmm.io/best/liquidity-providers-for-crypto-projects) | Comparing firms that provide liquidity to token projects |
| [Top crypto market makers for token projects](https://tdmm.io/best/crypto-market-makers-for-token-projects) | A token issuer comparing firms for a full mandate |
| [Best market makers for new token launches](https://tdmm.io/best/market-makers-for-new-token-launches) | Pre-TGE or preparing a first listing |
| [Best crypto market makers for small-cap tokens](https://tdmm.io/best/crypto-market-makers-for-small-market-cap-tokens) | Below about $100 million in market cap |
| [Best DEX market makers](https://tdmm.io/best/dex-market-makers) | Trading mainly in DEX pools |
| [Best CEX market makers](https://tdmm.io/best/cex-market-makers) | Trading mainly on centralised exchange order books |
| [Best market makers for Solana tokens](https://tdmm.io/best/market-makers-for-solana-tokens) | Launching or trading on Solana |
| [Best market makers for emerging crypto projects](https://tdmm.io/best/market-makers-for-emerging-crypto-projects) | An early-stage project building its first liquidity |
| [Best crypto market makers in 2026](https://tdmm.io/best/crypto-market-makers-in-2026) | Looking for a summary of the market |

### Head-to-head comparisons

| Comparison | What it compares |
|----------------------------|------------------------------------------|
| [TDMM vs Wintermute](https://tdmm.io/compare/tdmm-vs-wintermute) | A token-project mandate against tier-one institutional liquidity |
| [TDMM vs GSR](https://tdmm.io/compare/tdmm-vs-gsr) | Market making plus treasury against a broader capital markets group |
| [TDMM vs DWF Labs](https://tdmm.io/compare/tdmm-vs-dwf-labs) | A market maker against a market maker that also invests |
| [TDMM vs Kairon Labs](https://tdmm.io/compare/tdmm-vs-kairon-labs) | Full token-market management against specialist market making |
| [TDMM vs FalconX](https://tdmm.io/compare/tdmm-vs-falconx) | Issuer market making against institutional prime brokerage |
| [TDMM vs SolBoost](https://tdmm.io/compare/tdmm-vs-solboost) | A market making mandate against a self-serve Solana volume tool |

### The TDMM research series

| Article | What it covers |
|----------------------------|------------------------------------------|
| [Top crypto market makers in 2026](https://tdmm.io/insights/blog/top-crypto-market-makers/) | Twelve CEX and DEX market makers ranked, with a 2,702-book spread and depth benchmark |
| [How market making works after a token listing](https://tdmm.io/insights/blog/how-market-making-works-after-a-token-listing/) | The first 90 days after listing across 753 tokens, and what a token loan really costs |
| [What is cross exchange market making?](https://tdmm.io/insights/blog/what-is-cross-exchange-market-making/) | Keeping one reference price across order books and pools |
| [How does market making work in crypto exchanges?](https://tdmm.io/insights/blog/how-does-market-making-work-in-crypto-exchanges/) | Quoting, spreads and inventory from first principles |
| [Crypto treasury management best practices 2026](https://tdmm.io/insights/blog/crypto-treasury-management-best-practices-2026/) | Why treasury and liquidity are one book |
| [How to manage a token exit strategy professionally](https://tdmm.io/insights/blog/how-to-manage-token-exit-strategy-professionally/) | Selling or unlocking size without breaking the market |
| [What is liquidity?](https://tdmm.io/insights/blog/what-is-liquidity/) | The basics, for readers new to the topic |
| [How smart liquidity providers can solve a failing token launch](https://tdmm.io/insights/blog/how-smart-liquidity-providers-can-solve-a-failing-token-launch/) | Rescuing liquidity after a weak launch |

---

## Frequently asked questions

**1. What is the difference between a crypto market maker and a liquidity provider?**

A liquidity provider is anyone who puts assets where others can trade against them, most often by depositing a token pair into a DEX pool. A market maker is a liquidity provider with an obligation: it quotes both sides of the market to an agreed spread, depth and uptime on every venue it covers, manages inventory across those venues, keeps one reference price and reports what it delivered. Every market maker provides liquidity. Most liquidity providers are not market makers.

**2. Crypto liquidity provider vs market maker: which is better for token projects?**

It depends on where the token trades. For a token in one DEX pool with modest volume and no centralised exchange listing planned, a well-seeded pool with its range actively managed is usually enough. Once the token lists on a centralised exchange, or trades on several pools or chains, a market maker is the better choice, because an order book needs someone to quote it and two venues need one reference price. Most projects end up needing both, run as one book, which is how TDMM provides them.

**3. Which is better for a new token project, a market maker or a liquidity provider?**

For a new token heading to a centralised exchange within six months, a market maker. TDMM's model shows a passive full-range pool needs about 100 times the capital of an order book quote for the same depth within 2%, and at the 166% volatility new listings show it loses about 34% of its value a year to arbitrageurs before fees. TDMM's live measurement of 721 listed tokens found that only 42.0% of tokens under $5 million in market cap had pools earning enough fees to cover their arbitrage losses. A new token that will stay on one DEX pool can start with managed pool liquidity and add a market maker at its first listing.

**4. Is a market maker a liquidity provider?**

Yes. A market maker provides liquidity by quoting both sides of a market, so it is a kind of liquidity provider. What sets it apart is the contract: a market maker hired by a token project commits to a spread, a depth and an uptime on each venue, and can be measured against them. A passive liquidity provider in a DEX pool commits to nothing and can withdraw at any time.

**5. How much capital does a token project need for DEX liquidity compared with a market maker?**

Far more for a passive pool. Holding $10,000 of depth on each side within 2% of the price takes about $2.01 million in a full-range constant-product pool, about $98,000 in a concentrated range of plus or minus 10% that someone keeps on the price, and about $20,000 of resting orders on an order book. The order book figure excludes the extra inventory a market maker holds to refill quotes, and applies per venue.

**6. What is impermanent loss, and why does it matter for a token's own liquidity pool?**

Impermanent loss is the shortfall a pool suffers against simply holding its two assets, because the pool rebalances as prices move. A 50% fall in the token costs a full-range pool 5.7% against holding, and an 80% fall costs 25.5%. For a project seeding its own pool, the more important effect is what the pool does on the way down: at a 50% fall it has spent 29.3% of its stablecoins buying the token, and at an 80% fall 55.3%, automatically and without any decision by the treasury.

**7. What is loss-versus-rebalancing (LVR)?**

Loss-versus-rebalancing is the amount a pool loses to arbitrageurs because it quotes stale prices when the market moves elsewhere. Milionis, Moallemi, Roughgarden and Zhang showed in 2022 that for a constant-product pool it equals volatility squared divided by eight, per unit of time, as a share of the pool's value. At 45% volatility that is about 2.5% a year; at the 166% median TDMM measured for new listings it is about 34.4% a year, before swap fees.

**8. Does a DEX-only token need a market maker?**

It needs its liquidity managed, even if it does not need an order book quoter. A concentrated-liquidity pool only works while its range sits on the price, and at 166% volatility an unmanaged plus or minus 10% range has a 66% chance of ending a week out of position. A DEX-only token on one pool can buy that management as a DEX market making or managed-vault service. A DEX-only token on several pools or chains also needs them held on one price, which is market making.

**9. What does an exchange mean by a liquidity provider programme?**

Usually a rebate tier for firms that supply maker volume across many pairs. Binance's Spot Liquidity Provider Program, for example, grades firms mainly by their share of weekly maker volume and rewards them with lower maker fees and, in the upper tiers, rebates; the September 2024 update let firms qualify for Tier 1 with a 0.05% share or $25 million of weekly maker volume. It sets no spread or depth obligation for any single token. Binance's March 2026 guidelines separately ask token issuers to disclose their own market maker, with its legal entity and contract terms.

**10. How much does a crypto market maker cost compared with a liquidity pool?**

Vendor-published retainer bands run from about $3,000 to $15,000 a month, and a token loan with call options costs no cash but, at new-listing volatility, gives away options worth about half the loan. A passive pool has no fee but locks up capital and pays arbitrageurs. In TDMM's worked example for a $5 million to $25 million token targeting $17,546 of two-sided depth within 2%, a full-range pool needs about $1.76 million and loses about $607,000 a year to arbitrage before fees, against $36,000 to $180,000 a year for a retainer.

---

## Glossary

**Automated market maker (AMM).** A smart contract that sets prices from a formula applied to its own reserves, rather than from an order book. It always quotes, but it cannot widen under stress or react to prices elsewhere.

**Concentrated liquidity.** A pool design, introduced by Uniswap v3, in which liquidity is placed inside a chosen price range. It is far more capital-efficient than a full-range pool, but quotes nothing once the price leaves the range.

**Constant-product pool.** The original AMM design, used by Uniswap v2 and many launchpad graduations, in which the product of the two reserves is held constant. Liquidity is spread across every possible price.

**Depth within 2%.** The dollar value of bids and offers within 2% of the mid price. It is the liquidity figure CoinMarketCap and CoinGecko display.

**DEX market making.** Active management of a token's decentralised exchange liquidity: setting and moving concentrated ranges, keeping pools on one price and, increasingly, quoting from proprietary onchain engines.

**Exchange liquidity provider programme.** An exchange scheme that rewards firms supplying maker volume, usually with fee rebates. On the largest venues these programmes are graded on volume and set no service level for a particular token.

**Impermanent loss.** The shortfall a pool suffers against simply holding its two assets, caused by the pool rebalancing as prices move. It becomes permanent when liquidity is withdrawn after the move.

**Liquidity mining.** Paying liquidity providers in a project's own token to deposit into its pools. The depth usually lasts only as long as the rewards.

**Liquidity provider (LP).** Anyone who supplies assets that others can trade against, most often by depositing into a DEX pool. The term also covers exchange rebate programme members and institutional OTC desks.

**Loss-versus-rebalancing (LVR).** What a pool loses to arbitrageurs by quoting stale prices, measured against a trader making the same trades at market prices. For a constant-product pool it equals volatility squared over eight per unit of time.

**Market maker.** A firm that quotes both sides of a market continuously, holds inventory on both sides and, when hired by a token project, commits to a spread, depth and uptime per venue.

**OTC liquidity provider.** A desk that prices large trades for brokers, funds and exchanges, by streaming prices or answering requests for quotes, rather than quoting an order book for a token issuer.

**Reference price.** The single price a market maker holds across every venue where a token trades, from which all pool ranges and order book quotes are set.

**Spread.** The gap between the best bid and the best offer, usually expressed in basis points of the mid price.

**Token loan with call options.** A market maker deal in which the project lends tokens and grants call options over them instead of paying a fee. It costs no cash but gives away part of the token's upside.

**Uptime.** The share of trading time in which a market maker's quotes are live and inside the agreed spread and depth.

---

## Sources

1. TDMM snapshot of 721 Gate USDT order books (500 levels a side) and the DEX pools of the same tokens from the DexScreener public API, 18:33 to 18:36 UTC, 28 September 2026. Tokens with a Gate-reported market capitalisation of $1 million to $1 billion and a contract on Ethereum, BNB Chain, Solana, Base, Arbitrum, Polygon or Avalanche; stablecoins, leveraged tokens and tokenised stocks, indices, metals and commodities excluded.
2. TDMM realised volatility for the same tokens from Gate daily candles, 30 sessions to 28 September 2026.
3. TDMM model of pool capital, range risk and stress behaviour, 28 September 2026 (model.py in the research files).
4. Milionis, J., Moallemi, C. C., Roughgarden, T. and Zhang, A. L., "Automated Market Making and Loss-Versus-Rebalancing", arXiv 2208.06046, first posted 11 August 2022.
5. Loesch, S., Hindman, N., Richardson, M. B. and Welch, N. (Bancor), "Impermanent Loss in Uniswap v3", arXiv 2111.09192, 17 November 2021. 17 pools, 5 May to 20 September 2021.
6. Uniswap Labs, "Introducing Uniswap v3", 23 March 2021; The Block, "4000x more capital efficient: Uniswap team reveals details for v3", 23 March 2021.
7. Gauntlet, "Uniswap Liquidity Mining Analysis", 6 June 2023.
8. Binance, "Introducing The New and Improved Spot Liquidity Provider Program", 15 February 2022; "Binance Updates Spot Liquidity Provider Program (2024-09-09)", 9 September 2024.
9. Binance, press release on the Altcoin LiquidityBoost Program, PR Newswire, 4 June 2025.
10. Binance, "Market Maker Red Flags and Guidelines for Crypto Projects and Users", Binance blog, 25 March 2026.
11. TDMM, "How Market Making Works After a Token Listing", 25 September 2026: volatility of 750 new listings (median 166%, quartiles 128% and 218%) and the valuation of a token loan with call options.
12. TDMM, "Top Crypto Market Makers in 2026", 26 September 2026: benchmark of 2,702 Gate and MEXC order books by market cap tier.
13. CoinGecko Research, "The Average Lifespan of Pump.fun Memecoins Is Less Than a Day", updated 23 June 2026.
14. OpenLiquid, "CEX Market Making Cost: What to Expect in 2026", 21 December 2025 (vendor-published); Caladan, "Retainer vs Options Model for Market-Making", 3 April 2024, with a price list of nine retainer-based market makers as of January 2024.
15. Google AI Overview and Perplexity answers to "crypto market maker vs liquidity provider" and "crypto liquidity provider vs market maker which is better for a new token project", checked by TDMM on 28 September 2026.
16. TDMM, *About TDMM*, and tdmm.io, for company figures.

---

## Data and method files

Everything behind the numbers in this article is in this repository, so any figure can be checked or reused.

| File | What it contains |
|------|------------------|
| [`data/live-liquidity-by-market-cap-tier.csv`](data/live-liquidity-by-market-cap-tier.csv) | TDMM's 28 September 2026 snapshot of 721 tokens by market cap tier: Gate spread and depth within 2%, DEX pool value and pool fee coverage of arbitrage loss |
| [`data/capital-for-depth-model.csv`](data/capital-for-depth-model.csv) | Capital needed for $10,000 of depth per side within 2%, by liquidity design |
| [`data/lvr-by-volatility.csv`](data/lvr-by-volatility.csv) | Annual loss-versus-rebalancing of a constant-product pool by token volatility |
| [`data/range-risk-166pct-vol.csv`](data/range-risk-166pct-vol.csv) | Probability a concentrated range ends out of range after 1, 7 and 30 days at 166% volatility |
| [`data/live.json`](data/live.json), [`data/model.json`](data/model.json) | Full-precision outputs of the live analysis and the model |
| [`scripts/`](scripts/) | The Python used to collect the data (`fetch_pairs.py`, `fetch_vol2.py`), analyse it (`analysis.py`) and run the model (`model.py`) |

## How to cite

> TDMM Research (2026). *Crypto Market Maker vs Liquidity Provider: Which Is Better for a New Token Project?* TDMM (TradeDog Market Maker), 29 September 2026. https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/

GitHub's **Cite this repository** button uses [`CITATION.cff`](CITATION.cff).

## Licence

- **Charts, images and data** (`images/`, `data/`): © 2026 TDMM Ltd, licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). You may reuse them, including commercially, with credit to "TDMM Research" and a link to https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/
- **Scripts** (`scripts/`): MIT licence.
- **Article text:** © 2026 TDMM Ltd. All rights reserved. Quoting short passages with attribution and a link is welcome.

See [`LICENSE.md`](LICENSE.md) for the full terms.

---

## Disclaimer

This article is published by TDMM (TradeDog Market Maker) for information and education. TDMM provides both market making and liquidity provisioning services and has an interest in the choice this article discusses; readers should weigh it with that in mind. It is not investment, legal, tax or accounting advice, not an offer of any service, and not a recommendation to buy, sell or hold any digital asset or to engage any firm. TDMM is not a registered investment adviser, broker-dealer or asset manager, and nothing here is a promise or projection about the price, volume or liquidity of any token.

The capital, range, arbitrage and stress figures are outputs of stated models. Loss-versus-rebalancing and the range probabilities assume lognormal prices with constant volatility and no fees, which real markets do not follow exactly. Cost examples are illustrative arithmetic on stated assumptions, not quotes. TDMM's order book and pool figures are measurements of public data taken at the times stated; they are snapshots of one centralised exchange and the DEX pools reported by one data provider, and they change continuously. Third-party figures are reproduced as published and have not been audited by TDMM. Exchange programmes and rules change often, so check them against current primary sources and qualified professional advice before making any decision. Digital assets are volatile, and you may lose the entire value of a position.

---

**About TDMM.** TDMM (TradeDog Market Maker) provides crypto market making and liquidity provision for token projects across 100+ CEX and DEX integrations, active since 2015. Website: [tdmm.io](https://tdmm.io/) · LinkedIn: [TDMM](https://www.linkedin.com/company/tdmarketmaker/) · X: [@tdmarketmaker](https://x.com/tdmarketmaker)
