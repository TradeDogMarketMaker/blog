# How to publish this on GitHub

This folder is a complete, ready-to-push repository. It publishes the article two ways at once:

- **As the repository's `README.md`.** GitHub renders it on the repo's front page, and search engines and AI crawlers index github.com well.
- **As a GitHub Pages blog post** (`_posts/`), with SEO tags, a sitemap, an RSS feed, a canonical link back to tdmm.io, and JSON-LD for the FAQ, the dataset and the images.

## 1. Create the repository

**Assumption to check first:** everything below uses the account name **`tdmarketmaker`**, matching TDMM's X, LinkedIn and Instagram handles. If the GitHub account uses another name, replace `tdmarketmaker` in three places:

- `_config.yml` (`url`)
- `CITATION.cff` (`repository-code`)
- the `REPO` and `PAGES` lines of `build_github.py`, if you rebuild

Then set the repository up:

1. On GitHub, sign in as the TDMM account (or organisation) and choose **New repository**.
2. **Repository name:** `crypto-market-maker-vs-liquidity-provider`
3. **Description** (the "About" text):
   > Crypto market maker vs liquidity provider: which is better for a new token project? Capital, cost and live data from 721 tokens. By TDMM (TradeDog Market Maker).
4. Make it **Public**. Do **not** add a README, licence or .gitignore, because this folder already has them.
5. Create the repository.

## 2. Upload the files

**Option A, in the browser (no tools needed):**

1. On the empty repository page, click **uploading an existing file**.
2. Drag in the **contents** of this folder: every file and subfolder, not the folder itself.
3. Commit message: `Publish: Crypto market maker vs liquidity provider (TDMM Research, 29 Sep 2026)`
4. Click **Commit changes**.

If the browser upload drops the `_posts` folder because of the leading underscore, create it with **Add file → Create new file**, typing `_posts/` before the file name, and paste the post's content.

**Option B, with git:**

```bash
cd crypto-market-maker-vs-liquidity-provider
git init
git add .
git commit -m "Publish: Crypto market maker vs liquidity provider (TDMM Research, 29 Sep 2026)"
git branch -M main
git remote add origin https://github.com/tdmarketmaker/crypto-market-maker-vs-liquidity-provider.git
git push -u origin main
```

## 3. Repository settings

- **About panel (the gear icon beside About):**
  - **Website:** `https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/`
  - **Topics:** `crypto` `market-making` `market-maker` `liquidity-provider` `defi` `dex` `amm` `uniswap` `liquidity` `token-launch` `impermanent-loss` `crypto-research` `tdmm`
  - Tick **Releases** and untick **Packages** and **Deployments**, which keeps the sidebar tidy.
- **Social preview:** go to Settings → General → Social preview → Upload, and use `assets/github-social-preview-1280x640.png`. This is the image that shows when the repo link is shared.
- **Pages:** go to Settings → Pages → Build and deployment. Set Source to **Deploy from a branch**, the branch to **main**, and the folder to **/ (root)**. Save. After a minute or two the blog is live at:
  `https://tdmarketmaker.github.io/crypto-market-maker-vs-liquidity-provider/crypto-market-maker-vs-liquidity-provider/`
- **Citation:** the **Cite this repository** button appears automatically, because `CITATION.cff` is present.

## 4. Optional but recommended

- **Release:** create one under Releases → Draft a new release, with tag `v2026.09.29` and title "TDMM Research: Crypto market maker vs liquidity provider (29 Sep 2026)". Paste the short answer as the notes. Releases give the data a dated, citable snapshot.
- **DOI:** connect the repository at zenodo.org (GitHub integration), then create the release. Zenodo mints a DOI for the dataset, which research tools and AI engines treat as a strong citation source. Add the DOI to `CITATION.cff` afterwards.
- **Pin it:** on the TDMM GitHub profile, choose **Customize your pins** and pin this repository.
- **Link back from tdmm.io:** add a line near the article's sources, such as "Data and scripts: GitHub". Each copy then points to the other, and AI engines see one research entity across both sites.
- **Future articles:** reuse this layout. Each new pillar can go into this repo as a new `_posts/` file with its own `images/` and `data/` subfolders, or into one repo per study.

## Duplicate content

The Pages post sets `canonical_url` to the tdmm.io article, so Google credits tdmm.io as the original. The README states "Originally published at tdmm.io" in its first lines and links there.

## Files

| Path | Purpose |
|------|---------|
| `README.md` | The full article in GitHub Markdown, with a table of contents, data files, citation and licence |
| `_posts/2026-09-29-crypto-market-maker-vs-liquidity-provider.md` | The GitHub Pages blog post, with front matter (title, description, canonical, cover image, tags) and JSON-LD |
| `_config.yml`, `Gemfile`, `index.md` | Jekyll site settings (minima theme, jekyll-seo-tag, sitemap, feed) |
| `images/` | 18 TDMM-branded charts, 1920×1080, plus the 2000×800 X cover |
| `data/` | CSV and JSON outputs, plus a data dictionary (CC BY 4.0) |
| `scripts/` | The Python behind the data and model (MIT) |
| `assets/github-social-preview-1280x640.png` | The repository's social preview image |
| `LICENSE.md` | CC BY 4.0 for charts and data, MIT for scripts, all rights reserved for the text |
| `CITATION.cff` | The citation metadata behind GitHub's "Cite this repository" button |
