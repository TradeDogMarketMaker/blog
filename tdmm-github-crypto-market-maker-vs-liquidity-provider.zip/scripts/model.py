"""TDMM model: capital, arbitrage cost and range risk of passive pool liquidity vs an order book market maker.
All closed-form; assumptions printed. Output model.json."""
import json, math
from statistics import NormalDist
N = NormalDist()
out = {}

# 1. Capital to hold D dollars of depth per side within +/-2% of mid
D_side = 10_000
buy = math.sqrt(1.02) - 1          # quote in to lift price 2%, per $ of quote reserve
sell = 1 - math.sqrt(0.98)         # quote out to push price down 2%, per $ of quote reserve
full_tvl = 2 * D_side / min(buy, sell)       # binding side is the buy side
out["cp_buy_frac"] = buy; out["cp_sell_frac"] = sell
out["full_range_tvl_10k"] = full_tvl
ranges = {"+/-50%": 0.50, "+/-25%": 0.25, "+/-10%": 0.10, "+/-5%": 0.05}
cl = {}
for lab, a in ranges.items():
    # range [p(1-a), p(1+a)]; capital per unit liquidity relative to full range (2 L sqrt p)
    eff = 2 / ((1 - math.sqrt(1 - a)) + (1 - 1 / math.sqrt(1 + a)))
    cl[lab] = dict(a=a, efficiency=eff, tvl=full_tvl / eff)
out["cl"] = cl
out["orderbook_resting_10k"] = 2 * D_side    # $10k bids + $10k offers resting
out["two_sided_depth_frac_of_tvl"] = (buy + sell) / 2   # two-sided 2% depth as share of full-range TVL

# 2. Range risk: chance the price leaves a symmetric range within T, GBM, reflection principle (driftless log)
def p_end_outside(a, sigma_ann, days):
    s = sigma_ann * math.sqrt(days / 365)
    return (1 - N.cdf(math.log(1 + a) / s)) + N.cdf(math.log(1 - a) / s)
vols = {"Bitcoin-like 45%": 0.45, "Large-cap alt 80%": 0.80, "New listing median 166%": 1.66}
rr = {}
for vl, v in vols.items():
    rr[vl] = {lab: {"1d": p_end_outside(k, v, 1), "7d": p_end_outside(k, v, 7), "30d": p_end_outside(k, v, 30)}
              for lab, k in ranges.items()}
out["range_end_outside"] = rr
out["daily_sigma_166"] = 1.66 / math.sqrt(365)

# 3. Loss-versus-rebalancing (Milionis, Moallemi, Roughgarden, Zhang 2022): CPMM LVR rate = sigma^2/8 of pool value per year
lvr = {f"{int(s*100)}%": s * s / 8 for s in [0.45, 0.8, 1.0, 1.28, 1.66, 2.18]}
out["lvr_rate"] = lvr
# LVR scales with liquidity L, so the dollar cost of offering a given depth near the price
# is the same whether the liquidity is full range or concentrated (while in range).
# 4. Worked example: $5M-$25M token, TDMM top-quartile target $17,546 two-sided within 2%
target_two = 17_546
tvl_needed = target_two / ((buy + sell) / 2)  # two-sided depth ~ 1.0% of TVL
# use binding side for per-side symmetric target
tvl_needed_bind = 2 * (target_two / 2) / buy
sig = 1.66
lvr_year = tvl_needed_bind * sig ** 2 / 8
ex = dict(target_two_sided=target_two, tvl_full_range=tvl_needed_bind,
          tvl_cl_10=tvl_needed_bind / cl["+/-10%"]["efficiency"],
          lvr_year=lvr_year, lvr_day=lvr_year / 365)
for fee in [0.0025, 0.003, 0.01]:
    ex[f"breakeven_daily_volume_fee_{fee}"] = lvr_year / 365 / fee
ex["breakeven_turnover_0.3pct"] = ex["breakeven_daily_volume_fee_0.003"] / tvl_needed_bind
ex["orderbook_resting_per_venue"] = target_two
# retainer bands: OpenLiquid Dec 2025 $3k-$15k/month; Caladan Jan 2024 $1k-$7k per exchange per month
ex["retainer_year_low"] = 3_000 * 12
ex["retainer_year_high"] = 15_000 * 12
out["example"] = ex

# 5. What a -80% move does to the issuer's stablecoin side of a full-range pool
imp = {}
for r in [0.5, 0.2, 0.1]:
    imp[str(r)] = dict(stable_left=math.sqrt(r), stable_spent=1 - math.sqrt(r),
                       il=2 * math.sqrt(r) / (1 + r) - 1)
for r in [2.0, 5.0]:
    imp[str(r)] = dict(token_left=1 / math.sqrt(r), token_sold=1 - 1 / math.sqrt(r),
                       il=2 * math.sqrt(r) / (1 + r) - 1)
out["price_move"] = imp
json.dump(out, open("model.json", "w"), indent=1)
print(json.dumps(out, indent=1))
