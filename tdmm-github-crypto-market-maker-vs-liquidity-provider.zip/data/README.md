# Data dictionary

All files in this folder: © 2026 TDMM Ltd, CC BY 4.0. Credit "TDMM Research" with a link to https://tdmm.io/insights/blog/crypto-market-maker-vs-liquidity-provider/

## Live snapshot (`live-liquidity-by-market-cap-tier.csv`, `live.json`)

**When it was captured:** 28 September 2026, 18:33 to 18:36 UTC.

**Universe.** Gate USDT spot pairs for tokens with a Gate-reported market capitalisation of $1 million to $1 billion, and a contract on Ethereum, BNB Chain, Solana, Base, Arbitrum, Polygon or Avalanche. Stablecoins, leveraged tokens and tokenised stocks, indices, metals and commodities are excluded. That leaves 721 tokens with a two-sided book.

**Sources:**

- Gate API v4 order books, 500 levels a side.
- DexScreener `token-pairs` API: every DEX pool for each token.
- Gate daily candles, for 30-day realised volatility.

| Column | Meaning |
|--------|---------|
| `market_cap_tier` | The tier, by Gate-reported market capitalisation |
| `tokens` | The number of tokens in the tier |
| `median_gate_spread_bps` | Median best bid/offer spread on Gate, in basis points of the mid price |
| `median_gate_depth_2pct_usd` | Median two-sided USD value of Gate bids and offers within 2% of the mid price |
| `share_gate_books_thin_one_side_pct` | Share of Gate books with under $10,000 within 2% on the thinner side |
| `median_dex_pool_value_usd` | Median sum of DexScreener-reported liquidity across all of the token's pools |
| `share_tokens_dex_pools_under_10k_pct` | Share of tokens with under $10,000 in DEX pools in total |
| `share_tokens_pool_fees_cover_lvr_pct` | Share of tokens whose pools' 24-hour fees, at an assumed 0.3%, covered the estimated daily loss-versus-rebalancing (pool value × σ²/8 ÷ 365) |
| `tokens_in_lvr_test` | Tokens with a pool and volatility data |
| `median_30d_realised_vol_pct` | Median annualised 30-day close-to-close volatility |

**Caveats:**

- This is one exchange and one DEX data provider, captured in a single three-minute window.
- DEX liquidity and volume are as DexScreener reports them.
- The fee tier is an assumption.
- For concentrated pools, σ²/8 understates the loss per dollar of capital.

## Model (`model.json` and the three model CSVs)

These files hold closed-form arithmetic, and `scripts/model.py` reproduces every value.

- **Constant-product pool:** two-sided depth within 2% equals 1.0% of pool value.
- **Concentrated range [p(1−a), p(1+a)]:** capital efficiency is 2 / ((1 − √(1−a)) + (1 − 1/√(1+a))).
- **Range risk:** assumes lognormal, driftless prices. The probability given is that the price *ends* the period outside the range.
- **Loss-versus-rebalancing:** σ²/8 per year (Milionis, Moallemi, Roughgarden and Zhang, 2022, arXiv 2208.06046).
